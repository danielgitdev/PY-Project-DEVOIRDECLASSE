from flask import Flask, render_template, request,flash ,redirect ,g,session
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///login.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] ="secret_key"

#------------------Model(database)-----------------

db = SQLAlchemy(app)
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable= False)
    prenom = db.Column(db.String(80))
    email = db.Column(db.String(40),unique=True)
    motpass = db.Column(db.String(20),nullable = False)

db.create_all()

def __init__(self,id,name,prenom,email,motpass,passconf):
    self.id = id
    self.name = name
    self.prenom = prenom
    self.email = email
    self.motpass = motpass
    self.passconf = passconf

#------------------views------------------------------

@app.route('/', methods=["GET","POST"])
def begin():
    return render_template('home.html')



@app.route('/about', methods=["GET","POST"])
def index():
    return render_template('about.html') 

 
#-----------register implementation(control)----------

@app.route('/register', methods=["GET","POST"])
def signUp():
    return render_template('register.html')

@app.route('/signUp' , methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form['lname']
        prenom = request.form['fname']
        email = request.form['mail']
        motpass = request.form['passwd']
        passconf = request.form['confpasswd']
        
        
        logger = User.query.filter_by(email = email).first() 
        if logger:
            flash('email already exists') 
            return redirect('/register')
        if len(motpass) < 4:
            flash(" password must be at least 4 characters")
            return redirect('/register')
        elif passconf != motpass:
            flash("Your passwords do not match")
            return redirect('/register')
        else:
            logger = User(name = name, prenom = prenom, email = email, motpass = motpass)
            db.session.add(logger)
            db.session.commit()
            flash('success Account created')
            return render_template('login.html')

    
    
 #------------------login implementation(control)---------------------   
    
@app.route('/login', methods=["GET","POST"])
def tolog():
    return render_template('login.html')

    
@app.route('/index', methods=["GET","POST"])
def login():
    if request.method == "POST":
        session.pop('logger', None)
        email = request.form['email']
        motpass = request.form['passwd']
        session['logger'] = request.form['email']
        
        logger = User.query.filter_by(email = email).first() 
        
        if logger:
            if logger.motpass == motpass:
                if g.logger:
                    return render_template('index.html',logger = session['logger']) 
                flash('Session initialisation, please login again')
            else: 
                flash('password incorrect')
                return redirect('/login')
        else:
            flash('email not exist')
            return redirect('/login')
    return redirect('/login')

  #----------------logout implementation(control)-------------   
  
@app.before_request
def before_request():
    g.logger = None
    if 'logger' in session:
        g.logger = session['logger']

@app.route('/dropsession')
def dropsession():
    session.pop('logger', None)
    flash('successfully disconnected',category= 'success')
    return redirect('/login')

#---------------------app running----------------------
    
if __name__ == "__main__":
    app.run(debug = True)
    

